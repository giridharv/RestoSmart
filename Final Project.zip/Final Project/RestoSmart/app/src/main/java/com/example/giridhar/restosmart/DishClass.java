package com.example.giridhar.restosmart;

/**
 * Created by giridhar on 5/6/17.
 */

public class DishClass
{
    String description;
    String price;
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }




}
