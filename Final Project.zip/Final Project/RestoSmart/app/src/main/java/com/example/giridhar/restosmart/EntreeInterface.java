package com.example.giridhar.restosmart;

/**
 * Created by giridhar on 4/29/17.
 */

public interface EntreeInterface {

    public boolean isCategory();
    public boolean isDish();
}
